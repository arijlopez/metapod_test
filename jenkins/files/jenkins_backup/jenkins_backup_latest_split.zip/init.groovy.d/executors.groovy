import jenkins.model.*
Jenkins.instance.setNumExecutors(4)
